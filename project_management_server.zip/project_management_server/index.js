import express from 'express';
import { connectDB } from './src/config.js';
import {
  getallusers,
createuser,getuserbyid,updateusers,deleteUser,getMyTasks,updateTaskStatus} from './controllers/usercontroller.js';
import{
  getallprojects,createproject,assigntasks,getalltasks,getallusers as adminGetAllUsers,deleteUser,updateusers,updateproject as adminUpdateProject ,getuserbyid,getuserbymanager} from './controllers/admincontrollers.js';
import{
  createtask,gettaskbyproject,gettaskbyid,getalltasks as getalltasksc,updatetask} from './controllers/taskcontroller.js';
const app = express();
import{ updateproject,deleteproject,assignmanagertoproject,removemanagerfromproject,getprojectbyid,getprojectbymanager} from './controllers/projectcontroller.js';  
app.use(express.json());



// Root URL
app.get("/", (req, res) => {
  res.send("Test Express Server Running");
  console.log("GET / processed");
});

// ----- User Routes ----- //
app.get("/users", getallusers);
app.get("/users/:id", getuserbyid);
app.post("/users", createuser);
app.put("/users/:id", updateusers);
app.delete("/users/:id", deleteUser);

app.get("/users/:id/tasks", getMyTasks);
//===admin routes===//
app.get("/admin/projects", getallprojects);
app.post("/admin/projects", createproject);
app.put("/admin/projects/:id", updateproject);
app.delete("/admin/projects/:id", deleteproject); 
app.get("/admin/users", getallusers);
app.get("/admin/users/:id", getuserbyid);
app.put("/admin/users/:id", updateusers);
app.delete("/admin/users/:id", deleteUser);
app.get("/admin/users/manager/:manager_id", getuserbymanager);  

app.put("/tasks/:id/status", updateTaskStatus);

app.get("/projects", getallprojects);
app.post("/projects", createproject);
app.post("/tasks", assigntasks);
app.get("/tasks", getalltasks);

//===== Task Routes ===== //
app.post("/createtask", createtask);
app.get("/tasks/project/:project_id", gettaskbyproject);
app.get("/tasks/:task_id", gettaskbyid);
app.get("/alltasks", getalltasksc);
app.put("/tasks/:task_id", updatetask);


app.get("/allprojects", getallprojects);
app.post("/createproject", createproject);
app.put("/projects/:project_id", updateproject);
app.delete("/projects/:project_id", deleteproject);
app.post("/projects/:project_id/assignmanager", assignmanagertoproject);
app.post("/projects/:project_id/removemanager", removemanagerfromproject);
app.get("/projects/:project_id", getprojectbyid);
app.get("/projects/manager/:manager_id", getprojectbymanager);

// Start server
const PORT = 4400;
app.listen(PORT, () => {
  connectDB();
  console.log(`Express server started on port ${PORT}`);
});
