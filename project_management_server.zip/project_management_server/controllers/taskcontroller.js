import { getConnectionObject } from "../src/config.js";
export async function createtask(request, response){
    try {
        const conn = getConnectionObject();
        const { project_id, task_name, assigned_to, due_date, priority, status } = request.body;
        const qry = `INSERT INTO tasks (project_id, task_name, assigned_to, due_date, priority, status) VALUES (${project_id}, '${task_name}', '${assigned_to}', '${due_date}', '${priority || 'Medium'}', '${status || 'Pending'}')`;
        const [resultSet] = await conn.query(qry);
        response.status(201).send({ id: resultSet.insertId, project_id, task_name, assigned_to, due_date, priority, status });
    } catch (error) {
        console.error("Error creating task:", error);
        response.status(500).send("Something went wrong ");
    }
    
}
export async function gettaskbyproject(request, response){
    try {
        const conn = getConnectionObject();
        const { project_id } = request.params;
        const qry = `SELECT * FROM tasks WHERE project_id = ${project_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send(resultSet);
    } catch (error) {
        console.error("Error fetching tasks:", error);
        response.status(500).send("Something went wrong ");
    }
}
export async function gettaskbyid(request, response){
    try {
        const conn = getConnectionObject();
        const { task_id } = request.params;
        const qry = `SELECT * FROM tasks WHERE id = ${task_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send(resultSet);
    } catch (error) {
        console.error("Error fetching task:", error);
        response.status(500).send("Something went wrong ");
    }
}

export async function updatetask(request, response){
    try {
        const conn = getConnectionObject();
        const { task_id } = request.params;
        const { task_name, assigned_to, due_date, priority, status } = request.body;
        const qry = `UPDATE tasks SET task_name='${task_name}', assigned_to='${assigned_to}', due_date='${due_date}', priority='${priority}', status='${status}' WHERE id=${task_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send({ message: "Task updated successfully" });
    } catch (error) {
        console.error("Error updating task:", error);
        response.status(500).send("Something went wrong ");
    }
}
export async function deletetask(request, response){
    try {
        const conn = getConnectionObject();
        const { task_id } = request.params;
        const qry = `DELETE FROM tasks WHERE id = ${task_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send({ message: "Task deleted successfully" });
    } catch (error) {
        console.error("Error deleting task:", error);
        response.status(500).send("Something went wrong ");
    }
}
export async function getalltasks(request, response){
    try {
        const conn = getConnectionObject();
        const qry = `SELECT * FROM tasks`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send(resultSet);
    } catch (error) {
        console.error("Error fetching tasks:", error);
        response.status(500).send("Something went wrong ");
    }
}