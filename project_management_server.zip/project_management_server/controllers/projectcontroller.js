import { getConnectionObject } from "../src/config.js";

export async function getallprojects(request, response) {
    try {
        const conn = getConnectionObject();
        const qry = `SELECT * FROM projects`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send(resultSet);
    } catch (error) {
        console.error("Error fetching projects:", error);
        response.status(500).send("Something went wrong ");
    }
    
}
export async function createproject(request, response) {
    try {
        const conn = getConnectionObject();
        const { project_name, description, status } = request.body;
        const qry = `INSERT INTO projects (project_name, description, status) VALUES ('${project_name}', '${description}', '${status || 'Active'}')`;
        const [resultSet] = await conn.query(qry);
        response.status(201).send({ id: resultSet.insertId, project_name, description, status });
    } catch (error) {
        console.error("Error creating project:", error);
        response.status(500).send("Something went wrong ");
    }
}
export async function getprojectbyid(request, response){
    try {
        const conn = getConnectionObject();
        const { project_id } = request.params;
        const qry = `SELECT * FROM projects WHERE id = ${project_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send(resultSet);
    } catch (error) {
        console.error("Error fetching project:", error);
        response.status(500).send("Something went wrong ");
    }
}                                   
export async function getprojectbymanager(request, response){
    try {
        const conn = getConnectionObject();
        const { manager_id } = request.params;
        const qry = `SELECT * FROM projects WHERE manager_id = ${manager_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send(resultSet);
    } catch (error) {
        console.error("Error fetching projects by manager:", error);
        response.status(500).send("Something went wrong ");
    }
}               
export async function updateproject(request, response){
    try {
        const conn = getConnectionObject();
        const { project_id } = request.params;
        const { project_name, description, status } = request.body;
        const qry = `UPDATE projects SET project_name='${project_name}', description='${description}', status='${status}' WHERE id=${project_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send({ message: "Project updated successfully" });
    } catch (error) {
        console.error("Error updating project:", error);
        response.status(500).send("Something went wrong ");
    }
}
export async function deleteproject(request, response){
    try {
        const conn = getConnectionObject();
        const { project_id } = request.params;
        const qry = `DELETE FROM projects WHERE id = ${project_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send({ message: "Project deleted successfully" });
    } catch (error) {
        console.error("Error deleting project:", error);
        response.status(500).send("Something went wrong ");
    }
}
export async function assignmanagertoproject(request, response){
    try {
        const conn = getConnectionObject();
        const { project_id } = request.params;
        const { manager_id } = request.body;
        const qry = `UPDATE projects SET manager_id=${manager_id} WHERE id=${project_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send({ message: "Manager assigned to project successfully" });
    }   catch (error) {    
        console.error("Error assigning manager to project:", error);
        response.status(500).send("Something went wrong ");
    }                   
}
export async function removemanagerfromproject(request, response){
    try {
        const conn = getConnectionObject();
        const { project_id } = request.params;
        const qry = `UPDATE projects SET manager_id=NULL WHERE id=${project_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send({ message: "Manager removed from project successfully" });
    }   catch (error) {    
        console.error("Error removing manager from project:", error);
        response.status(500).send("Something went wrong ");
    }                   
}                       
                                 