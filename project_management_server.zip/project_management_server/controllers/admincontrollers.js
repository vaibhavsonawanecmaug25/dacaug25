import { getConnectionObject } from "../src/config.js";

export async function getallprojects(request, response) {
    try {
        const conn = getConnectionObject();
        const qry = `SELECT * FROM projects`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send(resultSet);
    } catch (error) {
        console.error("Error fetching projects:", error);
        response.status(500).send("Internal Server Error");
    }
    
}
export async function createproject(request, response) {
    try {
        const conn = getConnectionObject();
        const { project_name, description, status } = request.body;
        const qry = `INSERT INTO projects (project_name, description, status) VALUES ('${project_name}', '${description}', '${status || 'Active'}')`;
        const [resultSet] = await conn.query(qry);
        response.status(201).send({ id: resultSet.insertId, project_name, description, status });
    } catch (error) {
        console.error("Error creating project:", error);
        response.status(500).send("Internal Server Error");
    }
}
export async function assigntasks(request, response){
    try {
        const conn = getConnectionObject();
        const { project_id, task_name, assigned_to, due_date, priority, status } = request.body;
        const qry = `INSERT INTO tasks (project_id, task_name, assigned_to, due_date, priority, status) VALUES (${project_id}, '${task_name}', '${assigned_to}', '${due_date}', '${priority || 'Medium'}', '${status || 'Pending'}')`;
        const [resultSet] = await conn.query(qry);
        response.status(201).send({ id: resultSet.insertId, project_id, task_name, assigned_to, due_date, priority, status });
    } catch (error) {
        console.error("Error assigning tasks:", error);
        response.status(500).send("Internal Server Error");
    }
}
export async function getalltasks(request, response){
    try {
        const conn = getConnectionObject();
        const qry = `SELECT * FROM tasks`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send(resultSet);
    } catch (error) {
        console.error("Error fetching tasks:", error);
        response.status(500).send("Internal Server Error");
    }
}
 export async function updateproject(request, response){
    try {
        const conn = getConnectionObject();
        const { project_id } = request.params;
        const { project_name, description, status } = request.body;
        const qry = `UPDATE projects SET project_name='${project_name}', description='${description}', status='${status}' WHERE id=${project_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send({ message: "Project updated successfully" });
    } catch (error) {
        console.error("Error updating project:", error);
        response.status(500).send("Something went wrong ");
    }
}
export async function deleteproject(request, response){
    try {
        const conn = getConnectionObject();
        const { project_id } = request.params;
        const qry = `DELETE FROM projects WHERE id = ${project_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send({ message: "Project deleted successfully" });
    } catch (error) {
        console.error("Error deleting project:", error);
        response.status(500).send("Something went wrong ");
    }
}
export async function createuser(request, response) {
  try {
    const conn = getConnectionObject();
    const { name, email, password, role, status } = request.body;

    const password_hash = await bcrypt.hash(password, 10);

    const qry = `
      INSERT INTO users (name, email, password_hash, role, status)
      VALUES ('${name}', '${email}', '${password_hash}', '${role || 'Developer'}', '${status || 'Active'}')
    `;
    const [resultSet] = await conn.query(qry);

    if (resultSet.affectedRows === 1) {
      response.status(200).send({ message: "User Registered Successfully", user_id: resultSet.insertId });
    } else {
      response.status(500).send({ message: "User registration failed" });
    }
  } catch (error) {
    console.log("Error in createUser:", error);
    response.status(500).send({ message: "Something went wrong " });
  }
}




export async function updateusers(request, response) {
  try {
    const conn = getConnectionObject();
    const { name, email, password, role, status } = request.body;

    
    const password_hash = await bcrypt.hash(password, 10);

    
    const qry = `
      UPDATE users 
      SET name='${name}', email='${email}', password_hash='${password_hash}', role='${role || 'Developer'}', status='${status || 'Active'}'
      WHERE user_id=${request.params.id}
    `;

    const [resultSet] = await conn.query(qry);

 if (resultSet.affectedRows === 1) {
      response.status(200).send({ message: "User Updated Successfully" });
    } else {
      response.status(400).send({ message: "User not found or no changes made" });
    }
  } catch (error) {
    console.log("Error in updateUser:", error);
    response.status(500).send({ message: "Something went wrong while updating user" });
  }
}



export async function getallusers(request, response) {
  try {
    const conn = getConnectionObject();
    const qry = `SELECT user_id, name, email, role, status, created_at, updated_at FROM users`;
    const [rows] = await conn.query(qry);
    response.status(200).send(rows);
  } catch (error) {
    console.log("Error in getAllUsers:", error);
    response.status(500).send({ message: "Something went wrong while fetching users" });
  }
}


export async function getuserbyid(request, response) {
  try {
    const conn = getConnectionObject();
    const qry = `SELECT user_id, name, email, role, status, created_at, updated_at FROM users WHERE user_id=${request.params.id}`;
    const [rows] = await conn.query(qry);

    if (rows.length === 0) {
      response.status(404).send({ message: "User not found" });
    } else {
      response.status(200).send(rows[0]);
    }
  } catch (error) {
    console.log("Error in getUserById:", error);
    response.status(500).send({ message: "Something went wrong while fetching user" });
  }
}

export async function deleteUser(request, response) {
  try {
    const conn = getConnectionObject();
    const qry = `DELETE FROM users WHERE user_id=${request.params.id}`;
    const [resultSet] = await conn.query(qry);

    if (resultSet.affectedRows === 0) {
      response.status(404).send({ message: "User not found" });
    } else {
      response.status(200).send({ message: "User Deleted Successfully" });
    }
  } catch (error) {
    console.log("Error in deleteUser:", error);
    response.status(500).send({ message: "Something went wrong while deleting user" });
  }
}
export async function getuserbymanager(request, response){
    try {
        const conn = getConnectionObject();
        const { manager_id } = request.params;
        const qry = `SELECT * FROM users WHERE manager_id = ${manager_id}`;
        const [resultSet] = await conn.query(qry);
        response.status(200).send(resultSet);
    } catch (error) {
        console.error("Error fetching users by manager:", error);
        response.status(500).send("Something went wrong ");
    }
}
