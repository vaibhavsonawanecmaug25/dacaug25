// src/config.js
import { createConnection } from "mysql2/promise";

let conn = null;

export async function connectDB() {
  try {
    conn = await createConnection({
      host: 'localhost',
      user: 'root',
      password: 'cdac1234',
      database: 'project_management',
      port: 3306
    });
    console.log(conn);
    console.log("Database connected successfully!");
  } catch (error) {
    console.log("Database connection failed:", error.message);
  }
}

export function getConnectionObject() {
  return conn;
}
// At the bottom of config.js
connectDB();

